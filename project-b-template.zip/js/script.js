function setup() {
  let canvas = createCanvas(800, 600);
  canvas.parent("canvasContainer");
  background(220);
}

function draw() {
  //
}